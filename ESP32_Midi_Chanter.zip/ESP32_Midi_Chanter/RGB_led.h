#ifndef RGB_LED_H
#define RGB_LED_H

#include <Arduino.h>

void rgbLedSetup();
void setStatusLED(uint32_t colour);

#endif
