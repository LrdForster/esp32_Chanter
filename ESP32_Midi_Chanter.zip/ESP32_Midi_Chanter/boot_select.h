#pragma once

// Returns true if the boot button is held at startup (requesting OTA)
bool isOTAModeRequested();
