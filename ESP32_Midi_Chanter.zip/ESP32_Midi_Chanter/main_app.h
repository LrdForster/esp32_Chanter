#pragma once


#define NUM_STATUS_LEDS 1      // If you only have one RGB LED

// Called once at program startup
void mainAppSetup();

// Called repeatedly in loop
void mainAppLoop();
