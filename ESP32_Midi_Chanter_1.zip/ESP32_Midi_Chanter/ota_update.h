#pragma once

void otaSetup();
void otaLoop();
